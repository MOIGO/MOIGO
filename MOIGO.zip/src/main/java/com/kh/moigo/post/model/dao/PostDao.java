package com.kh.moigo.post.model.dao;

public interface PostDao {

}
