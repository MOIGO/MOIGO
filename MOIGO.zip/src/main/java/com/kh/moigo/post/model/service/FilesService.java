package com.kh.moigo.post.model.service;

import org.springframework.stereotype.Service;

@Service
public interface FilesService {

}
