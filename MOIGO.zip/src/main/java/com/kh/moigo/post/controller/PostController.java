package com.kh.moigo.post.controller;

import org.springframework.stereotype.Controller;

@Controller
public class PostController {

}
