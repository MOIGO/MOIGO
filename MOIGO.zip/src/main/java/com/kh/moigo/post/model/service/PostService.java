package com.kh.moigo.post.model.service;

public interface PostService {

}
