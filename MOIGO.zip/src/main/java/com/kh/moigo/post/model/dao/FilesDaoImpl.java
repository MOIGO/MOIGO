package com.kh.moigo.post.model.dao;

import org.springframework.stereotype.Repository;

@Repository
public class FilesDaoImpl implements FilesDao {

}
