package com.kh.moigo.schedule.model.service;

import org.springframework.stereotype.Service;

@Service
public class ScheduleServiceImpl implements ScheduleService {

}
