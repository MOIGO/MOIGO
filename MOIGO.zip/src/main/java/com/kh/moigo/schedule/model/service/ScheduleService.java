package com.kh.moigo.schedule.model.service;

public interface ScheduleService {

}
