package com.kh.moigo.schedule.model.dao;

public interface ScheduleDao {

}
