package com.kh.moigo.schedule.model.dao;

import org.springframework.stereotype.Repository;

@Repository
public class ScheduleDaoImpl implements ScheduleDao {

}
