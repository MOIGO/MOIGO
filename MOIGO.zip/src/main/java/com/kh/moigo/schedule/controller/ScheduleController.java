package com.kh.moigo.schedule.controller;

import org.springframework.stereotype.Controller;

@Controller
public class ScheduleController {

}
