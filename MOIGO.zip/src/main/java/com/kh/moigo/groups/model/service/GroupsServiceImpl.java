package com.kh.moigo.groups.model.service;

import org.springframework.stereotype.Service;

@Service

public class GroupsServiceImpl implements GroupsService {

}
