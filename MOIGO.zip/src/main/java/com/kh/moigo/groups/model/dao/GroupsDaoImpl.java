package com.kh.moigo.groups.model.dao;

import org.springframework.stereotype.Repository;

@Repository
public class GroupsDaoImpl implements GroupsDao {

}
