package com.kh.moigo.groups.model.service;

public interface GroupsService {

}
