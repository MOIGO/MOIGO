package com.kh.moigo.groups.model.dao;

public interface GroupsDao {

}
