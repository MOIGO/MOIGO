package com.kh.moigo.member.model.service;

import com.kh.moigo.member.model.vo.Member;

public interface MemberService {

	Member selectOne(String memberNo); 
	
}
